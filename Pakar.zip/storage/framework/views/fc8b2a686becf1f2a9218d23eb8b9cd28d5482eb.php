<?php $__env->startSection('content'); ?>
<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> 
      <a href="<?php echo e(url('/index')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
      <a href="<?php echo e(url('/datakulit')); ?>" title="Data Jenis Kulit" class="tip-bottom"><i class="icon-home"></i> Data Jenis Kulit</a>
    </div>
  </div>
<!--End-breadcrumbs-->

  <!-- container fluid -->
  <div class="container-fluid">

  <!--Chart-box-->    
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title bg_lg">
          <span class="icon"><i class="icon-plus"></i></span>
          <h5>Tambah Jenis Kulit</h5>
        </div>
        
        <div class="widget-content">
          <div class="controls controls-row">
            <label class="span3 m-wrap"><b>Kode Jenis Kulit</b></label>
            <label class="span3 m-wrap"><b>Nama Jenis Kulit</b></label>
          </div>
          <!-- form action -->
          <form action="<?php echo e(url('/simpanjeniskulit')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <div class="controls controls-row">
            <input type="text" autofocus="" name="kode" placeholder="" class="span3 m-wrap">
            <input type="text" name="nama" placeholder="" class="span3 m-wrap">
            <button type="submit" class="btn btn-primary span2 m-wrap">SIMPAN</button>
            <button type="reset" class="btn btn-warning span2 m-wrap">RESET</button>
          </div>
          </form>
        </div>

      </div>
    </div>
  <!--End-Chart-box--> 

  <?php echo $__env->make('helper/message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!--Chart-box-->    
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title bg_lg">
          <span class="icon"><i class="icon-signal"></i></span>
          <h5>Data Jenis Kulit</h5>
        </div>
        <!-- table untuk menampilkan data gejala -->
        <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th style="text-align: left; font-size: 13px">No</th>
                  <th style="text-align: left; font-size: 13px">Kode Jenis Kulit</th>
                  <th style="text-align: left; font-size: 13px">Nama Jenis Kulit</th>
                  <th style="text-align: left; font-size: 13px">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td style="font-size: 13px"><?php echo e($no++); ?></td>
                  <td style="font-size: 13px"><?php echo e($tampil->kjeniskulit); ?></td>
                  <td style="font-size: 13px"><?php echo e($tampil->njeniskulit); ?></td>
                  <td>
                    <a href="" class="btn btn-mini btn-info">Edit</a>
                    
                    <!-- proses hapus -->
                    <a href="#myHapus<?php echo e($tampil->id); ?>" data-toggle="modal" class="btn btn-mini btn-danger">Hapus</a>
                    <!-- model untuk hapus data -->
                      <div id="myHapus<?php echo e($tampil->id); ?>" class="modal hide">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3>Peringatan Sistem !</h3>
                      </div>
                      <div class="modal-body">
                        <p>Apakah anda yakin akan menghapus data dengan kode <b><?php echo e($tampil->kjeniskulit); ?></b></p>
                      </div>
                      <div class="modal-footer"> <a class="btn btn-primary" href="<?php echo e(url('deletejeniskulit')); ?>/kdjensikulit=<?php echo e($tampil->kjeniskulit); ?>">Hapus</a> <a data-dismiss="modal" class="btn" href="#">Batal</a> </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

      </div>
    </div>
  <!--End-Chart-box--> 

  </div>
  <!-- end container fluid --> 

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>