<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="<?php if($pages == 'index'): ?> active <?php endif; ?>">
      <a href="<?php echo e(url('/index')); ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a>
    </li>

    <!-- sidebar digunakan untuk admin -->
    <?php if(Auth::user()->role == 2): ?> 
    <li class="<?php if($pages == 'datapengguna'): ?> active <?php endif; ?>">
      <a href="<?php echo e(url('/datapengguna')); ?>"><i class="icon icon-home"></i> <span>Data Pengguna</span></a>
    </li>
    <li class="<?php if($pages == 'datajeniskulit'): ?> active <?php endif; ?>">
      <a href="<?php echo e(url('/datajeniskulit')); ?>"><i class="icon icon-home"></i> <span>Data Jenis Kulit</span></a>
    </li>
    
    <li class="<?php if($pages == 'datapenyakit'): ?> active <?php endif; ?>">
      <a href="<?php echo e(url('/datapenyakit')); ?>"><i class="icon icon-home"></i> <span>Data Penyakit</span></a>
    </li>
  	<?php endif; ?>
    
    <!-- sidebar yang digunakan perawat -->
    <?php if(Auth::user()->role == 1): ?> 
    <li class="<?php if($pages == 'pendaftaranpasienbaru'): ?> active <?php endif; ?>">
      <a href="<?php echo e(url('/pendaftaranpasienbaru')); ?>"><i class="icon icon-home"></i> <span>Pendaftaran Pasien Baru</span></a>
    </li>
    <li class="<?php if($pages == 'pendaftaranpasien'): ?> active <?php endif; ?>">
      <a href="<?php echo e(url('/pendaftaranpasien')); ?>"><i class="icon icon-home"></i> <span>Pendaftaran Pengobatan</span></a>
    </li>
  	<?php endif; ?>

    <!--  sidabar yang digunakan oleh admin dan perawat -->
    <?php if(Auth::user()->role == 1 ): ?> 
    <li class="submenu <?php if($pages == 'rst'): ?> active <?php endif; ?>"> 
      <a href="#"><i class="icon icon-list"></i><span>Rekap Data Pasien</span> <span class="label label-important">1</span></a>
      <ul>
        <li class="<?php if($pages == 'rst'): ?> active <?php endif; ?>">
          <a href="<?php echo e(url('/rekappasistemterdaftar')); ?>">Pasien Terdaftar</a>
        </li>
      </ul>
    </li>
    <?php endif; ?>

    <!-- default sidebar -->
    <li class="">
      <a href=""><i class="icon icon-home"></i> <span>Akses Sistem Pakar</span></a>
    </li>
    
  </ul>
</div>
<!--sidebar-menu-->