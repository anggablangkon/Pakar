<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap-responsive.min.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/fullcalendar.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/matrix-style.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/matrix-media.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/select2.css')); ?>" />
	<link href="<?php echo e(asset('/css/font-awesome.css')); ?>" rel="stylesheet" />
	
	

</head>
<body>

	<!-- navbar -->
	<?php echo $__env->make('assets/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- end navbar -->

	<!-- sidebar -->
	<?php echo $__env->make('assets/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- end sidebar -->

	<!-- content -->
	<?php echo $__env->yieldContent('content'); ?>
	<!-- end content -->


	<!--Footer-part-->
	<div class="row-fluid">
	  <div id="footer" class="span12"> 2013 &copy; Matrix Admin. Brought to you by <a href="http://themedesigner.in">Themedesigner.in</a> </div>
	</div>
	<!--end-Footer-part-->


	<!-- javascript -->
	<script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/jquery.ui.custom.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/jquery.uniform.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/select2.min.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/jquery.dataTables.min.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/matrix.js')); ?>"></script> 
	<script src="<?php echo e(asset('/js/matrix.tables.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/jquery.validate.js')); ?>"></script> 

	<?php echo $__env->yieldContent('javascript'); ?>


</body>
</html>