<?php $__env->startSection('content'); ?>
<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> 
      <a href="<?php echo e(url('/index')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
      <a href="index.html" title="Rekap Data Pasien" class="tip-bottom"><i class="icon-home"></i> Rekap Data Pasien</a>
    </div>
  </div>
<!--End-breadcrumbs-->

  <!-- container fluid -->
  <div class="container-fluid">


  <!--Chart-box-->    
    <div class="row-fluid">
      <!-- message -->
      <?php echo $__env->make('helper/message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="widget-box">
        <div class="widget-title bg_lg"><span class="icon"><i class="icon-signal"></i></span>
          <h5>Rekap Data Pasien</h5>
        </div>

        <!-- table untuk menampilkan data gejala -->
        <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th style="text-align: left; font-size: 13px">No</th>
                  <th style="text-align: left; font-size: 13px">No Anggota</th>
                  <th style="text-align: left; font-size: 13px">Nama</th>
                  <th style="text-align: left; font-size: 13px">Jenis Kelamin</th>
                  <th style="text-align: left; font-size: 13px">Tgl Lahir</th>
                  <th style="text-align: left; font-size: 13px">Alamat</th>
                  <th style="text-align: left; font-size: 13px">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $datarekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td style="font-size: 13px"><?php echo e($no++); ?></td>
                  <td style="font-size: 13px">PS-0<?php echo e($tampil->noanggota); ?></td>
                  <td style="font-size: 13px"><?php echo e($tampil->nama); ?></td>
                  <td style="font-size: 13px"><?php if($tampil->jk == 'P'): ?> Pria <?php else: ?> Wanita <?php endif; ?></td>
                  <td style="font-size: 13px"><?php echo e($tampil->tgl_lahir); ?></td>
                  <td style="font-size: 13px"><?php echo e($tampil->alamat); ?></td>
                  <td>
                    <a href="" class="btn btn-mini btn-info">Edit</a>
                    <a href="#myHapus<?php echo e($tampil->noanggota); ?>" data-toggle="modal" class="btn btn-mini btn-danger">Hapus</a>
                    <!-- modal untuk hapus data -->
                    <div id="myHapus<?php echo e($tampil->noanggota); ?>" class="modal hide">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3>Peringatan Sistem !</h3>
                      </div>
                      <div class="modal-body">
                        <p>Apakah anda yakin akan menghapus data dengan nama <b><?php echo e($tampil->nama); ?></b></p>
                      </div>
                      <div class="modal-footer"> <a class="btn btn-primary" href="<?php echo e(url('/deleteanggota')); ?>/Idanggota=<?php echo e($tampil->noanggota); ?>">Hapus</a> <a data-dismiss="modal" class="btn" href="#">Batal</a> </div>
                    </div>

                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

      </div>
    </div>
  <!--End-Chart-box--> 

  </div>
  <!-- end container fluid --> 

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>