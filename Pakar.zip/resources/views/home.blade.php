<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <meta http-equiv="Refresh" content="0; {{ url('/index') }}">
</body>
</html>